/*
 * family-api: all trusted logic. No network or SDK construction happens in this file,
 * so it can be unit-tested with fakes (see ../test/logic.test.js).
 *
 * Trust model
 *  - `user` is the account returned by Appwrite for the caller's own JWT. It is never
 *    taken from the request body.
 *  - Every action that touches a family re-checks, on the server, that the caller holds
 *    a CONFIRMED membership in that family's Appwrite Team and that the Team is registered
 *    in the `families` table.
 *  - Rows are written with read permission for exactly one role: team:<familyId>
 *    (or user:<id> for bookmarks). Clients get no table-level write permission at all.
 */
import { Query, Permission, Role, ID } from 'node-appwrite';

export const TABLES = {
  families: 'families',
  profiles: 'profiles',
  posts: 'posts',
  comments: 'comments',
  reactions: 'reactions',
  bookmarks: 'bookmarks'
};

export const LIMITS = {
  bodyMax: 2000,
  commentMax: 500,
  nameMax: 60,
  imageMaxBytes: 8 * 1024 * 1024,
  avatarMaxBytes: 1024 * 1024
};

const ID_RE = /^[A-Za-z0-9][A-Za-z0-9._-]{0,35}$/;
const KINDS = ['text', 'photo', 'video', 'short'];
const IMAGE_MIMES = ['image/jpeg', 'image/png', 'image/webp'];

export class ApiError extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
}
const bad = (m) => new ApiError(400, 'bad_request', m);
const forbidden = (m = 'You do not have access to do that.') => new ApiError(403, 'forbidden', m);
const missing = (m = 'Not found.') => new ApiError(404, 'not_found', m);

const sdkCode = (e) => (e && typeof e.code === 'number' ? e.code : 0);

export function createApi({ users, teams, db, storage, cfg, now = () => Date.now() }) {
  const databaseId = cfg.databaseId;
  const bucketId = cfg.bucketId;
  const maxOwned = cfg.maxOwnedFamilies;
  const maxVideoBytes = cfg.maxVideoMB * 1024 * 1024;

  /* ---------- small data helpers ---------- */
  const listRows = (tableId, queries) => db.listRows({ databaseId, tableId, queries });
  const createRow = (tableId, rowId, data, permissions) =>
    db.createRow({ databaseId, tableId, rowId, data, permissions });
  const updateRow = (tableId, rowId, data) => db.updateRow({ databaseId, tableId, rowId, data });
  const deleteRow = (tableId, rowId) => db.deleteRow({ databaseId, tableId, rowId });
  async function getRowOrNull(tableId, rowId) {
    try {
      return await db.getRow({ databaseId, tableId, rowId });
    } catch (e) {
      if (sdkCode(e) === 404) return null;
      throw e;
    }
  }
  async function firstRow(tableId, queries) {
    const r = await listRows(tableId, [...queries, Query.limit(1)]);
    return r.rows[0] || null;
  }
  async function getFileOrNull(fileId) {
    try {
      return await storage.getFile({ bucketId, fileId });
    } catch (e) {
      if (sdkCode(e) === 404) return null;
      throw e;
    }
  }
  async function deleteFileQuiet(fileId) {
    if (!fileId) return;
    try {
      await storage.deleteFile({ bucketId, fileId });
    } catch (e) {
      if (sdkCode(e) !== 404) throw e;
    }
  }
  const teamRead = (familyId) => [Permission.read(Role.team(familyId))];

  /* ---------- input validation ---------- */
  function idOf(value, label) {
    if (typeof value !== 'string' || !ID_RE.test(value)) throw bad(`${label} is not valid.`);
    return value;
  }
  function textOf(value, label, { max, min = 0 }) {
    if (typeof value !== 'string') throw bad(`${label} must be text.`);
    const t = value.replace(/\r\n/g, '\n').trim();
    if (t.length < min) throw bad(`${label} is too short.`);
    if (t.length > max) throw bad(`${label} is too long (max ${max}).`);
    return t;
  }

  /* ---------- identity and membership ---------- */
  function requireVerifiedUser(user) {
    if (!user || !user.$id) throw new ApiError(401, 'unauthenticated', 'Please sign in.');
    if (user.status === false) throw new ApiError(403, 'blocked', 'This account is disabled.');
    if (!user.emailVerification) throw new ApiError(403, 'email_not_verified', 'Verify your email first.');
  }
  async function confirmedMemberships(user) {
    const res = await users.listMemberships({ userId: user.$id, queries: [Query.limit(100)] });
    return res.memberships.filter((m) => m.confirm === true);
  }
  /** Throws unless the caller is a confirmed member of a REGISTERED family. */
  async function requireMember(user, familyIdRaw) {
    const familyId = idOf(familyIdRaw, 'familyId');
    const mine = await confirmedMemberships(user);
    const m = mine.find((x) => x.teamId === familyId);
    if (!m) throw forbidden('You are not a member of this family.');
    const family = await getRowOrNull(TABLES.families, familyId);
    if (!family) throw forbidden('This family is not set up.');
    return { familyId, isOwner: Array.isArray(m.roles) && m.roles.includes('owner'), family, membership: m };
  }
  async function syncLabel(user, hasFamily) {
    const labels = Array.isArray(user.labels) ? user.labels : [];
    const has = labels.includes('family');
    if (hasFamily && !has) {
      await users.updateLabels({ userId: user.$id, labels: [...labels, 'family'] });
    } else if (!hasFamily && has) {
      await users.updateLabels({ userId: user.$id, labels: labels.filter((l) => l !== 'family') });
    }
  }

  /* ---------- file ownership + normalisation ---------- */
  /**
   * A file may be attached only if (a) it carries update permission for the caller, which a
   * browser can only grant to itself, (b) it is readable by the target family's team, and
   * (c) it passes type and size checks. Then its permissions are rewritten to exactly
   * read(team:familyId), so the uploader's own extra permissions disappear and the file can
   * never be attached a second time.
   */
  async function claimFile(user, familyId, fileId, purpose) {
    idOf(fileId, 'fileId');
    const file = await getFileOrNull(fileId);
    if (!file) throw bad('The uploaded file was not found.');
    const perms = file.$permissions || [];
    if (!perms.includes(Permission.update(Role.user(user.$id)))) throw forbidden('That file is not yours to attach.');
    if (!perms.includes(Permission.read(Role.team(familyId)))) throw forbidden('That file was not uploaded for this family.');
    const mime = String(file.mimeType || '').toLowerCase();
    const size = Number(file.sizeOriginal || 0);
    if (purpose === 'photo') {
      if (!IMAGE_MIMES.includes(mime)) throw bad('Photos must be JPEG, PNG or WebP.');
      if (size > LIMITS.imageMaxBytes) throw bad('That photo is too large.');
    } else if (purpose === 'avatar') {
      if (!IMAGE_MIMES.includes(mime)) throw bad('Profile pictures must be JPEG, PNG or WebP.');
      if (size > LIMITS.avatarMaxBytes) throw bad('That profile picture is too large.');
    } else {
      if (!mime.startsWith('video/')) throw bad('That file is not a video.');
      if (size > maxVideoBytes) throw bad('That video is too large.');
    }
    await storage.updateFile({ bucketId, fileId, permissions: teamRead(familyId) });
    return { fileId, mime, size };
  }

  /* ---------- cascade deletes ---------- */
  async function deleteWhere(tableId, queries, deadline, onRow) {
    for (;;) {
      const page = await listRows(tableId, [...queries, Query.limit(50)]);
      if (page.rows.length === 0) return true;
      for (const row of page.rows) {
        if (onRow) await onRow(row);
        await deleteRow(tableId, row.$id);
      }
      if (now() > deadline) return false;
    }
  }
  async function purgePost(post, deadline) {
    const byPost = [Query.equal('postId', [post.$id])];
    if (!(await deleteWhere(TABLES.comments, byPost, deadline))) return false;
    if (!(await deleteWhere(TABLES.reactions, byPost, deadline))) return false;
    if (!(await deleteWhere(TABLES.bookmarks, byPost, deadline))) return false;
    await deleteFileQuiet(post.mediaFileId);
    await deleteRow(TABLES.posts, post.$id);
    return true;
  }
  async function loadPostInFamily(familyId, postIdRaw) {
    const postId = idOf(postIdRaw, 'postId');
    const post = await getRowOrNull(TABLES.posts, postId);
    if (!post || post.familyId !== familyId) throw missing('That post was not found in this family.');
    return post;
  }

  /* ================= actions ================= */
  const actions = {
    /** Lists the caller's confirmed, registered families. Also keeps the `family` label in sync. */
    async listFamilies({ user }) {
      const mine = await confirmedMemberships(user);
      let families = [];
      if (mine.length) {
        const ids = mine.map((m) => m.teamId);
        const res = await listRows(TABLES.families, [Query.equal('$id', ids), Query.limit(100)]);
        const registered = new Set(res.rows.map((r) => r.$id));
        families = mine
          .filter((m) => registered.has(m.teamId))
          .map((m) => ({
            id: m.teamId,
            name: m.teamName,
            role: Array.isArray(m.roles) && m.roles.includes('owner') ? 'owner' : 'member'
          }));
      }
      await syncLabel(user, families.length > 0);
      const owned = await listRows(TABLES.families, [Query.equal('ownerId', [user.$id]), Query.limit(1)]);
      return { families, canCreateFamily: owned.total < maxOwned, maxOwnedFamilies: maxOwned };
    },

    /** The browser creates the Team (it becomes owner); this call registers it as a family. */
    async registerFamily({ user, body }) {
      const teamId = idOf(body.teamId, 'teamId');
      const mine = await confirmedMemberships(user);
      const m = mine.find((x) => x.teamId === teamId);
      if (!m || !Array.isArray(m.roles) || !m.roles.includes('owner')) {
        throw forbidden('Only the owner of a team can register it as a family.');
      }
      if (await getRowOrNull(TABLES.families, teamId)) throw new ApiError(409, 'already_registered', 'This family already exists.');
      const owned = await listRows(TABLES.families, [Query.equal('ownerId', [user.$id]), Query.limit(1)]);
      if (owned.total >= maxOwned) {
        throw new ApiError(409, 'quota', `You can own up to ${maxOwned} families.`);
      }
      const name = textOf(m.teamName || '', 'Family name', { min: 1, max: LIMITS.nameMax });
      await createRow(TABLES.families, teamId, { ownerId: user.$id, name }, teamRead(teamId));
      await syncLabel(user, true);
      return { family: { id: teamId, name, role: 'owner' } };
    },

    async saveProfile({ user, body }) {
      const { familyId } = await requireMember(user, body.familyId);
      const displayName = textOf(body.displayName, 'Name', { min: 1, max: LIMITS.nameMax });
      const key = `${familyId}_${user.$id}`;
      const existing = await firstRow(TABLES.profiles, [Query.equal('profileKey', [key])]);
      let avatarFileId = existing ? existing.avatarFileId || '' : '';
      if (body.avatarFileId !== undefined && body.avatarFileId !== avatarFileId) {
        const next = body.avatarFileId === '' || body.avatarFileId === null ? '' : String(body.avatarFileId);
        if (next) await claimFile(user, familyId, next, 'avatar');
        const old = avatarFileId;
        avatarFileId = next;
        if (old) await deleteFileQuiet(old);
      }
      const data = { familyId, userId: user.$id, profileKey: key, displayName, avatarFileId };
      const row = existing
        ? await updateRow(TABLES.profiles, existing.$id, { displayName, avatarFileId })
        : await createRow(TABLES.profiles, ID.unique(), data, teamRead(familyId));
      return { profile: { id: row.$id, userId: user.$id, displayName, avatarFileId } };
    },

    async createPost({ user, body }) {
      const { familyId } = await requireMember(user, body.familyId);
      const kind = body.kind;
      if (!KINDS.includes(kind)) throw bad('Unknown post type.');
      const text = textOf(body.body ?? '', 'Post', { max: LIMITS.bodyMax });
      const data = { familyId, authorId: user.$id, kind, body: text };
      if (kind === 'text') {
        if (!text) throw bad('Write something first.');
        if (body.mediaFileId) throw bad('A text post cannot have a file.');
      } else {
        if (!body.mediaFileId) throw bad('This post type needs a file.');
        const f = await claimFile(user, familyId, body.mediaFileId, kind === 'photo' ? 'photo' : 'video');
        data.mediaFileId = f.fileId;
        data.mediaMime = f.mime.slice(0, 32);
        data.mediaSize = f.size;
      }
      const row = await createRow(TABLES.posts, ID.unique(), data, teamRead(familyId));
      return { postId: row.$id };
    },

    async editPost({ user, body }) {
      const { familyId } = await requireMember(user, body.familyId);
      const post = await loadPostInFamily(familyId, body.postId);
      if (post.authorId !== user.$id) throw forbidden('Only the author can edit a post.');
      const text = textOf(body.body ?? '', 'Post', { max: LIMITS.bodyMax });
      if (!text && !post.mediaFileId) throw bad('A post needs text or a file.');
      await updateRow(TABLES.posts, post.$id, { body: text });
      return { ok: true };
    },

    async deletePost({ user, body, deadline }) {
      const { familyId, isOwner } = await requireMember(user, body.familyId);
      const post = await loadPostInFamily(familyId, body.postId);
      if (post.authorId !== user.$id && !isOwner) throw forbidden('Only the author or a family owner can delete this post.');
      const done = await purgePost(post, deadline);
      return { done };
    },

    async createComment({ user, body }) {
      const { familyId } = await requireMember(user, body.familyId);
      const post = await loadPostInFamily(familyId, body.postId);
      const text = textOf(body.body, 'Comment', { min: 1, max: LIMITS.commentMax });
      const row = await createRow(
        TABLES.comments,
        ID.unique(),
        { familyId, postId: post.$id, authorId: user.$id, body: text },
        teamRead(familyId)
      );
      return { commentId: row.$id };
    },

    async deleteComment({ user, body }) {
      const { familyId, isOwner } = await requireMember(user, body.familyId);
      const commentId = idOf(body.commentId, 'commentId');
      const c = await getRowOrNull(TABLES.comments, commentId);
      if (!c || c.familyId !== familyId) throw missing('That comment was not found in this family.');
      let allowed = c.authorId === user.$id || isOwner;
      if (!allowed) {
        const post = await getRowOrNull(TABLES.posts, c.postId);
        allowed = !!post && post.familyId === familyId && post.authorId === user.$id;
      }
      if (!allowed) throw forbidden('You cannot delete this comment.');
      await deleteRow(TABLES.comments, c.$id);
      return { ok: true };
    },

    async toggleReaction({ user, body }) {
      const { familyId } = await requireMember(user, body.familyId);
      const post = await loadPostInFamily(familyId, body.postId);
      const key = `${post.$id}_${user.$id}`;
      const existing = await firstRow(TABLES.reactions, [Query.equal('reactionKey', [key])]);
      if (existing) {
        await deleteRow(TABLES.reactions, existing.$id);
        return { liked: false };
      }
      try {
        await createRow(
          TABLES.reactions,
          ID.unique(),
          { familyId, postId: post.$id, userId: user.$id, reactionKey: key },
          teamRead(familyId)
        );
      } catch (e) {
        if (sdkCode(e) !== 409) throw e; // a double tap already created it
      }
      return { liked: true };
    },

    async toggleBookmark({ user, body }) {
      const { familyId } = await requireMember(user, body.familyId);
      const post = await loadPostInFamily(familyId, body.postId);
      const key = `${user.$id}_${post.$id}`;
      const existing = await firstRow(TABLES.bookmarks, [Query.equal('bookmarkKey', [key])]);
      if (existing) {
        await deleteRow(TABLES.bookmarks, existing.$id);
        return { saved: false };
      }
      try {
        await createRow(
          TABLES.bookmarks,
          ID.unique(),
          { familyId, userId: user.$id, postId: post.$id, bookmarkKey: key },
          [Permission.read(Role.user(user.$id))]
        );
      } catch (e) {
        if (sdkCode(e) !== 409) throw e;
      }
      return { saved: true };
    },

    /** Owner only. Call repeatedly until `done` is true; each call stays inside the time budget. */
    async deleteFamily({ user, body, deadline }) {
      const { familyId, isOwner } = await requireMember(user, body.familyId);
      if (!isOwner) throw forbidden('Only a family owner can delete the family.');
      const byFamily = [Query.equal('familyId', [familyId])];
      if (!(await deleteWhere(TABLES.reactions, byFamily, deadline))) return { done: false };
      if (!(await deleteWhere(TABLES.comments, byFamily, deadline))) return { done: false };
      if (!(await deleteWhere(TABLES.bookmarks, byFamily, deadline))) return { done: false };
      const postDone = await deleteWhere(TABLES.posts, byFamily, deadline, (p) => deleteFileQuiet(p.mediaFileId));
      if (!postDone) return { done: false };
      const profDone = await deleteWhere(TABLES.profiles, byFamily, deadline, (p) => deleteFileQuiet(p.avatarFileId));
      if (!profDone) return { done: false };
      await deleteRow(TABLES.families, familyId);
      try {
        await teams.delete({ teamId: familyId });
      } catch (e) {
        if (sdkCode(e) !== 404) throw e;
      }
      return { done: true };
    }
  };

  /* ---------- scheduled cleanup (no user) ---------- */
  /** Deletes uploads older than one hour that no post or profile refers to. Safe to run by anyone. */
  async function sweep(deadline) {
    const cutoff = new Date(now() - 60 * 60 * 1000).toISOString();
    let removed = 0;
    let cursor = null;
    while (now() < deadline) {
      const q = [Query.lessThan('$createdAt', cutoff), Query.limit(50)];
      if (cursor) q.push(Query.cursorAfter(cursor));
      const page = await storage.listFiles({ bucketId, queries: q });
      if (!page.files.length) break;
      for (const f of page.files) {
        const inPost = await firstRow(TABLES.posts, [Query.equal('mediaFileId', [f.$id])]);
        const inProfile = inPost ? null : await firstRow(TABLES.profiles, [Query.equal('avatarFileId', [f.$id])]);
        if (!inPost && !inProfile) {
          await deleteFileQuiet(f.$id);
          removed += 1;
        }
      }
      cursor = page.files[page.files.length - 1].$id;
      if (page.files.length < 50) break;
    }
    return { removed };
  }

  /* ---------- entry ---------- */
  async function handle({ user, body, deadline }) {
    try {
      if (!user) {
        // No signed-in caller: only the scheduler or the Console may run the cleanup, and
        // a request that names an action without credentials is simply unauthenticated.
        if (body && body.action) throw new ApiError(401, 'unauthenticated', 'Please sign in.');
        return { status: 200, json: { ok: true, ...(await sweep(deadline)) } };
      }
      requireVerifiedUser(user);
      const name = body && body.action;
      if (typeof name !== 'string' || !Object.prototype.hasOwnProperty.call(actions, name)) {
        throw bad('Unknown action.');
      }
      const result = await actions[name]({ user, body: body || {}, deadline });
      return { status: 200, json: { ok: true, ...result } };
    } catch (e) {
      if (e instanceof ApiError) {
        return { status: e.status, json: { ok: false, error: e.code, message: e.message } };
      }
      return { status: 500, json: { ok: false, error: 'server_error', message: 'Something went wrong on the server.' }, cause: e };
    }
  }

  return { handle, actions };
}
